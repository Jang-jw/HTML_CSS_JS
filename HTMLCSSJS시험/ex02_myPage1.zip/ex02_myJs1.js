

$("#move").on("click",function(){
    $("#div2").css("margin-left",100)
    $("#div3").css("margin-left",200)
    $("#div4").css("margin-left",300)
})
$("#effect").on("click",function(){
    $("#div1").css("border-top-right-radius",50)
    $("#div1").css("border-bottom-left-radius",50)
    $("#div2").css("border-top-right-radius",50)
    $("#div2").css("border-bottom-left-radius",50)
    $("#div3").css("border-top-right-radius",50)
    $("#div3").css("border-bottom-left-radius",50)
    $("#div4").css("border-top-right-radius",50)
    $("#div4").css("border-bottom-left-radius",50)
})